﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FallingObjectsNoah
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void LblQuestion_Click(object sender, EventArgs e)
        {

        }

        private void LblAnswerQuestion_Click(object sender, EventArgs e)
        {
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.lblAnswerQuestion.Hide();
            this.lblAnswer.Hide();
        }

        private void BtnCalculate_Click(object sender, EventArgs e)
        {
            this.lblAnswerQuestion.Show();
            this.lblAnswer.Show();

            double height, time;

            time = double.Parse(txtTime.Text);

            height = 100 - 0.5 * 9.8 * Math.Pow(time, 2);

            this.lblAnswer.Text = Convert.ToString(height) + " m";

            if (height < 0)
                this.lblAnswer.Text = "Object has already hit the ground!";

            if (time < 0)
                this.lblAnswer.Text = "Please use positive numbers.";



            





        }
    }
}
